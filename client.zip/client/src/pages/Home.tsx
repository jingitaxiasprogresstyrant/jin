import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import SpecialOffer from "@/components/SpecialOffer";
import FeaturedMenu from "@/components/FeaturedMenu";
import AboutUs from "@/components/AboutUs";
import Testimonials from "@/components/Testimonials";
import ReservationBanner from "@/components/ReservationBanner";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { useEffect } from "react";

export default function Home() {
  useEffect(() => {
    // Smooth scrolling for anchor links
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A') {
        const href = target.getAttribute('href');
        if (href && href.startsWith('#') && href !== '#') {
          e.preventDefault();
          const targetId = href;
          const targetElement = document.getElementById(targetId.substring(1));
          if (targetElement) {
            window.scrollTo({
              top: targetElement.getBoundingClientRect().top + window.scrollY - 80,
              behavior: 'smooth'
            });
          }
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <HeroSection />
      <SpecialOffer />
      <FeaturedMenu />
      <AboutUs />
      <Testimonials />
      <ReservationBanner />
      <ContactSection />
      <Footer />
    </div>
  );
}
