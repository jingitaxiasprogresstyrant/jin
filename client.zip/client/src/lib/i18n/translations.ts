export type Language = 'en' | 'pt-BR';

export const translations = {
  'en': {
    // Header
    'nav.home': 'Home',
    'nav.menu': 'Menu',
    'nav.about': 'About Us',
    'nav.testimonials': 'Testimonials',
    'nav.contact': 'Contact',
    'nav.reservations': 'Reservations',

    // Hero Section
    'hero.title': 'Welcome to Garfield Restaurant',
    'hero.subtitle': 'Authentic Italian Cuisine',
    'hero.cta': 'View Our Menu',
    'hero.booking': 'Book a Table',

    // Special Offer
    'special.title': 'Today\'s Special Offer',
    'special.subtitle': 'Lasagna Monday',
    'special.description': 'Every Monday, enjoy our famous lasagna with a complimentary dessert. Garfield\'s favorite day just got better!',
    'special.cta': 'Order Now',

    // Featured Menu
    'menu.title': 'Our Featured Menu',
    'menu.subtitle': 'Delicious Italian Dishes',
    'menu.cta': 'View Full Menu',
    'menu.loading': 'Loading menu items...',

    // About Us
    'about.title': 'About Garfield Restaurant',
    'about.subtitle': 'Our Story',
    'about.description1': 'Founded in 2015, Garfield Restaurant began with a simple mission: to serve authentic Italian cuisine in a cozy, welcoming atmosphere where every guest feels like family.',
    'about.description2': 'Our head chef, inspired by traditional recipes from various regions of Italy, crafts each dish with love and attention to detail. We source the freshest ingredients locally whenever possible and import specialty items directly from Italy.',
    'about.special': 'What makes us special',
    'about.feature1.title': 'Fresh Ingredients',
    'about.feature1.description': 'We source only the freshest, highest-quality ingredients for our dishes.',
    'about.feature2.title': 'Traditional Recipes',
    'about.feature2.description': 'Our recipes have been perfected over generations and stay true to authentic Italian traditions.',
    'about.feature3.title': 'Cozy Atmosphere',
    'about.feature3.description': 'Our restaurant provides a warm, inviting space where you can enjoy your meal in comfort.',

    // Testimonials
    'testimonials.title': 'What Our Customers Say',
    'testimonials.subtitle': 'Don\'t just take our word for it - hear from our satisfied customers.',
    
    // Reservation Banner
    'reservation.title': 'Reserve Your Table',
    'reservation.description': 'Book your dining experience at Garfield Restaurant. Perfect for family dinners, romantic dates, or special celebrations.',
    'reservation.cta': 'Book Now',

    // Contact Section
    'contact.title': 'Contact Us',
    'contact.subtitle': 'Get in Touch',
    'contact.description': 'Have questions or feedback? We\'d love to hear from you. Fill out the form below and we\'ll get back to you as soon as possible.',
    'contact.form.name': 'Your Name',
    'contact.form.email': 'Your Email',
    'contact.form.message': 'Your Message',
    'contact.form.submit': 'Send Message',
    'contact.form.success': 'Thank you! Your message has been sent.',
    'contact.form.error': 'There was an error sending your message. Please try again.',
    'contact.info.location': 'Location',
    'contact.info.hours': 'Opening Hours',
    'contact.info.hours.weekdays': 'Monday - Friday: 11am - 10pm',
    'contact.info.hours.weekends': 'Saturday - Sunday: 10am - 11pm',
    'contact.info.phone': 'Phone',
    'contact.info.email': 'Email',

    // Footer
    'footer.rights': 'All rights reserved.',
    'footer.credit': 'Site made by Nome: Enzo Daniel de Souza e Lima / RA: 923204355 / UNINOVE - CAMPUS MEMORIAL'
  },
  'pt-BR': {
    // Header
    'nav.home': 'Início',
    'nav.menu': 'Cardápio',
    'nav.about': 'Sobre Nós',
    'nav.testimonials': 'Depoimentos',
    'nav.contact': 'Contato',
    'nav.reservations': 'Reservas',

    // Hero Section
    'hero.title': 'Bem-vindo ao Restaurante Garfield',
    'hero.subtitle': 'Autêntica Culinária Italiana',
    'hero.cta': 'Ver Nosso Cardápio',
    'hero.booking': 'Reservar uma Mesa',

    // Special Offer
    'special.title': 'Oferta Especial de Hoje',
    'special.subtitle': 'Segunda da Lasanha',
    'special.description': 'Todas as segundas, desfrute da nossa famosa lasanha com uma sobremesa grátis. O dia favorito do Garfield ficou ainda melhor!',
    'special.cta': 'Peça Agora',

    // Featured Menu
    'menu.title': 'Nosso Cardápio em Destaque',
    'menu.subtitle': 'Deliciosos Pratos Italianos',
    'menu.cta': 'Ver Cardápio Completo',
    'menu.loading': 'Carregando itens do cardápio...',

    // About Us
    'about.title': 'Sobre o Restaurante Garfield',
    'about.subtitle': 'Nossa História',
    'about.description1': 'Fundado em 2015, o Restaurante Garfield começou com uma missão simples: servir autêntica culinária italiana em um ambiente acolhedor, onde cada cliente se sente como parte da família.',
    'about.description2': 'Nosso chef principal, inspirado por receitas tradicionais de várias regiões da Itália, prepara cada prato com amor e atenção aos detalhes. Utilizamos os ingredientes mais frescos disponíveis localmente e importamos itens especiais diretamente da Itália.',
    'about.special': 'O que nos torna especiais',
    'about.feature1.title': 'Ingredientes Frescos',
    'about.feature1.description': 'Utilizamos apenas os ingredientes mais frescos e de alta qualidade em nossos pratos.',
    'about.feature2.title': 'Receitas Tradicionais',
    'about.feature2.description': 'Nossas receitas foram aperfeiçoadas ao longo de gerações e permanecem fiéis às tradições italianas autênticas.',
    'about.feature3.title': 'Ambiente Aconchegante',
    'about.feature3.description': 'Nosso restaurante oferece um espaço acolhedor onde você pode desfrutar da sua refeição com conforto.',

    // Testimonials
    'testimonials.title': 'O Que Nossos Clientes Dizem',
    'testimonials.subtitle': 'Não acredite apenas em nossa palavra - ouça o que nossos clientes satisfeitos têm a dizer.',
    
    // Reservation Banner
    'reservation.title': 'Reserve Sua Mesa',
    'reservation.description': 'Agende sua experiência gastronômica no Restaurante Garfield. Perfeito para jantares em família, encontros românticos ou celebrações especiais.',
    'reservation.cta': 'Reservar Agora',

    // Contact Section
    'contact.title': 'Contate-nos',
    'contact.subtitle': 'Entre em Contato',
    'contact.description': 'Tem perguntas ou feedback? Adoraríamos ouvir de você. Preencha o formulário abaixo e entraremos em contato o mais breve possível.',
    'contact.form.name': 'Seu Nome',
    'contact.form.email': 'Seu Email',
    'contact.form.message': 'Sua Mensagem',
    'contact.form.submit': 'Enviar Mensagem',
    'contact.form.success': 'Obrigado! Sua mensagem foi enviada.',
    'contact.form.error': 'Houve um erro ao enviar sua mensagem. Por favor, tente novamente.',
    'contact.info.location': 'Localização',
    'contact.info.hours': 'Horário de Funcionamento',
    'contact.info.hours.weekdays': 'Segunda - Sexta: 11h - 22h',
    'contact.info.hours.weekends': 'Sábado - Domingo: 10h - 23h',
    'contact.info.phone': 'Telefone',
    'contact.info.email': 'Email',

    // Footer
    'footer.rights': 'Todos os direitos reservados.',
    'footer.credit': 'Site feito por Nome: Enzo Daniel de Souza e Lima / RA: 923204355 / UNINOVE - CAMPUS MEMORIAL'
  }
};