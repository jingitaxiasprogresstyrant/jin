import { useState, useEffect } from "react";
import catLogo from '../assets/cats.jpg';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full bg-white ${scrolled ? 'bg-opacity-95 shadow-md' : 'bg-opacity-90'} z-50 transition-all duration-300`}>
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center">
          <div className="h-14 w-14 rounded-full overflow-hidden flex items-center justify-center mr-3 border-2 border-garfield-orange">
            <img src={catLogo} alt="Cat Logo" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="font-comic text-2xl font-bold text-garfield-orange">Garfield <span className="text-garfield-brown">Restaurant</span></h1>
            <p className="text-xs text-garfield-light-brown">Lasagna & More</p>
          </div>
        </div>
        
        {/* Language Switcher and Mobile Menu Button */}
        <div className="flex items-center gap-2 lg:hidden">
          <LanguageSwitcher />
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="text-garfield-brown focus:outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
          </button>
        </div>
        
        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center space-x-8">
          <nav className="flex space-x-6">
            <a href="#home" className="font-medium text-garfield-orange hover:text-garfield-yellow transition duration-300">{t('nav.home')}</a>
            <a href="#menu" className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.menu')}</a>
            <a href="#about" className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.about')}</a>
            <a href="#testimonials" className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.testimonials')}</a>
            <a href="#contact" className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.contact')}</a>
          </nav>
          <LanguageSwitcher />
          <a href="#reservation" className="bg-garfield-orange text-white px-4 py-2 rounded-lg hover:bg-garfield-yellow transition duration-300">{t('nav.reservations')}</a>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      <div className={`${mobileMenuOpen ? 'block' : 'hidden'} lg:hidden bg-white py-4 px-4 shadow-inner`}>
        <nav className="flex flex-col space-y-4">
          <a href="#home" onClick={() => setMobileMenuOpen(false)} className="font-medium text-garfield-orange hover:text-garfield-yellow transition duration-300">{t('nav.home')}</a>
          <a href="#menu" onClick={() => setMobileMenuOpen(false)} className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.menu')}</a>
          <a href="#about" onClick={() => setMobileMenuOpen(false)} className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.about')}</a>
          <a href="#testimonials" onClick={() => setMobileMenuOpen(false)} className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.testimonials')}</a>
          <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="font-medium hover:text-garfield-orange transition duration-300">{t('nav.contact')}</a>
          <a href="#reservation" onClick={() => setMobileMenuOpen(false)} className="bg-garfield-orange text-white px-4 py-2 rounded-lg hover:bg-garfield-yellow transition duration-300 text-center">{t('nav.reservations')}</a>
        </nav>
      </div>
    </header>
  );
}
