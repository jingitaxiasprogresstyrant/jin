import cesarMarcelo from '../assets/cesar-marcelo.png';
import giulianoGalli from '../assets/giuliano-galli.png';
import pedroPiza from '../assets/pedro-piza.png';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function Testimonials() {
  const { t, language } = useLanguage();
  
  const testimonials = [
    {
      id: 1,
      text: language === 'en' 
        ? "The lasagna at Garfield Restaurant is simply incredible. Layers of perfectly cooked pasta, rich meat sauce, and just the right amount of cheese. It's my go-to comfort food!"
        : "A lasanha do Restaurante Garfield é simplesmente incrível. Camadas de massa perfeitamente cozida, molho de carne rico e a quantidade certa de queijo. É minha comida favorita para momentos de conforto!",
      name: "Cesar Marcelo",
      role: language === 'en' ? "Loyal customer since 2020" : "Cliente fiel desde 2020",
      avatar: cesarMarcelo,
      stars: 5
    },
    {
      id: 2,
      text: language === 'en'
        ? "This place has become our family's favorite spot for weekend dinners. The staff is friendly, the atmosphere is cozy, and the food is consistently delicious. The Garfield's-style pizza is to die for!"
        : "Este lugar se tornou o favorito da nossa família para jantares de fim de semana. A equipe é simpática, o ambiente é aconchegante e a comida é sempre deliciosa. A pizza estilo Garfield é de morrer!",
      name: "Giuliano Galli",
      role: language === 'en' ? "Regular visitor" : "Visitante regular",
      avatar: giulianoGalli,
      stars: 5
    },
    {
      id: 3,
      text: language === 'en'
        ? "I held my birthday party here and couldn't be happier with the service. The staff went above and beyond to make it special, and everyone raved about the food. Their tiramisu is the perfect way to end a meal!"
        : "Realizei minha festa de aniversário aqui e não poderia estar mais feliz com o serviço. A equipe foi além para tornar tudo especial, e todos elogiaram a comida. O tiramisu deles é o fim perfeito para uma refeição!",
      name: "Pedro Piza",
      role: language === 'en' ? "Event host" : "Anfitrião de evento",
      avatar: pedroPiza,
      stars: 4.5
    }
  ];

  return (
    <section id="testimonials" className="py-16 px-4 bg-garfield-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl font-bold mb-4">{t('testimonials.title')}</h2>
          <p className="max-w-2xl mx-auto text-garfield-light-brown">{t('testimonials.subtitle')}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map(testimonial => (
            <div key={testimonial.id} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="flex items-center mb-4">
                <div className="text-garfield-orange">
                  {[...Array(Math.floor(testimonial.stars))].map((_, i) => (
                    <i key={i} className="fas fa-star"></i>
                  ))}
                  {testimonial.stars % 1 !== 0 && (
                    <i className="fas fa-star-half-alt"></i>
                  )}
                </div>
              </div>
              <p className="text-garfield-brown italic mb-6">{testimonial.text}</p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full mr-4 bg-cover bg-center" style={{ backgroundImage: `url(${testimonial.avatar})` }} />
                <div>
                  <h4 className="font-bold">{testimonial.name}</h4>
                  <p className="text-garfield-light-brown text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
