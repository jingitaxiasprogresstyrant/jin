import { useState } from "react";
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function ContactSection() {
  const { toast } = useToast();
  const { t, language } = useLanguage();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: `${formData.subject}: ${formData.message}`
        }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to submit form');
      }
      
      toast({
        title: language === 'en' ? "Message Sent!" : "Mensagem Enviada!",
        description: language === 'en' 
          ? "Thank you for your message. We will get back to you soon."
          : "Obrigado por sua mensagem. Entraremos em contato em breve.",
      });
      
      setFormData({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    } catch (error) {
      console.error('Error submitting form:', error);
      toast({
        title: language === 'en' ? "Error" : "Erro",
        description: language === 'en'
          ? "There was a problem sending your message. Please try again."
          : "Houve um problema ao enviar sua mensagem. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactInfo = [
    {
      id: 1,
      title: t('contact.info.location'),
      details: ["Rua Deputado Salvador Julianelli, s/n - Barra Funda, São Paulo - SP, 05001-900"],
      icon: "fas fa-map-marker-alt"
    },
    {
      id: 2,
      title: t('contact.info.hours'),
      details: [
        language === 'en' 
          ? "Monday - Friday: 11:00 AM - 10:00 PM" 
          : "Segunda - Sexta: 11:00 - 22:00",
        language === 'en'
          ? "Saturday - Sunday: 10:00 AM - 11:00 PM"
          : "Sábado - Domingo: 10:00 - 23:00"
      ],
      icon: "fas fa-clock"
    },
    {
      id: 3,
      title: t('contact.info.phone'),
      details: [
        language === 'en' 
          ? "Reservations: (11) 91234-5678" 
          : "Reservas: (11) 91234-5678",
        language === 'en'
          ? "Takeout Orders: (11) 91234-5678"
          : "Pedidos para Viagem: (11) 91234-5678"
      ],
      icon: "fas fa-phone-alt"
    },
    {
      id: 4,
      title: t('contact.info.email'),
      details: ["info@uninovegarfieldrestaurant.com", "reservas@uninovegarfieldrestaurant.com"],
      icon: "fas fa-envelope"
    }
  ];

  return (
    <section id="contact" className="py-16 px-4 bg-white">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl font-bold mb-4">{t('contact.title')}</h2>
          <p className="max-w-2xl mx-auto text-garfield-light-brown">{t('contact.description')}</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="order-2 lg:order-1">
            <form id="contact-form" className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block mb-2 font-medium">{t('contact.form.name')}</label>
                  <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    value={formData.name}
                    onChange={handleChange}
                    placeholder={language === 'en' ? "John Doe" : "João Silva"} 
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-garfield-orange"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block mb-2 font-medium">{t('contact.form.email')}</label>
                  <input 
                    type="email" 
                    id="email" 
                    name="email" 
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="email@exemplo.com" 
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-garfield-orange"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="subject" className="block mb-2 font-medium">
                  {language === 'en' ? "Subject" : "Assunto"}
                </label>
                <input 
                  type="text" 
                  id="subject" 
                  name="subject" 
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder={language === 'en' ? "Reservation Inquiry" : "Consulta sobre Reserva"} 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-garfield-orange"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block mb-2 font-medium">{t('contact.form.message')}</label>
                <textarea 
                  id="message" 
                  name="message" 
                  value={formData.message}
                  onChange={handleChange}
                  rows={5} 
                  placeholder={language === 'en' ? "How can we help you?" : "Como podemos ajudar você?"} 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-garfield-orange"
                  required
                />
              </div>
              
              <div>
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-garfield-orange text-white px-6 py-3 rounded-lg font-medium hover:bg-garfield-yellow transition duration-300 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center">
                      <span className="inline-block animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></span>
                      {language === 'en' ? "Sending..." : "Enviando..."}
                    </span>
                  ) : (
                    t('contact.form.submit')
                  )}
                </button>
              </div>
            </form>
          </div>
          
          <div className="order-1 lg:order-2">
            <div className="bg-garfield-cream p-8 rounded-xl">
              <h3 className="font-playfair text-2xl font-bold mb-6">
                {language === 'en' ? "Restaurant Information" : "Informações do Restaurante"}
              </h3>
              
              <div className="space-y-6">
                {contactInfo.map(info => (
                  <div key={info.id} className="flex items-start">
                    <div className="bg-garfield-orange p-3 rounded-full mr-4 text-white">
                      <i className={info.icon}></i>
                    </div>
                    <div>
                      <h4 className="font-bold text-lg mb-1">{info.title}</h4>
                      {info.details.map((detail, index) => (
                        <p key={index} className="text-garfield-light-brown">{detail}</p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-8">
                <div className="w-full h-48 rounded-lg overflow-hidden">
                  <div className="w-full h-full object-cover bg-[url('https://images.unsplash.com/photo-1471306224500-6d0d218be372?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-center" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
