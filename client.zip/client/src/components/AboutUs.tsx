import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function AboutUs() {
  const { t, language } = useLanguage();
  
  const features = [
    {
      id: 1,
      title: t('about.feature1.title'),
      description: t('about.feature1.description'),
      icon: "fas fa-utensils"
    },
    {
      id: 2,
      title: t('about.feature2.title'),
      description: t('about.feature2.description'),
      icon: "fas fa-cheese"
    },
    {
      id: 3,
      title: t('about.feature3.title'),
      description: t('about.feature3.description'),
      icon: "fas fa-users"
    }
  ];

  return (
    <section id="about" className="py-16 px-4 bg-white">
      <div className="container mx-auto max-w-6xl">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <div className="relative">
              <div className="rounded-2xl shadow-xl w-full h-[400px] bg-cover bg-center" style={{ backgroundImage: "url('/images/about-restaurant.png')" }} />
              <div className="absolute -bottom-8 -right-8 bg-garfield-orange rounded-xl p-4 shadow-lg hidden md:block">
                <p className="font-comic text-white text-xl">
                  {language === 'en' ? 'Serving smiles since 2015' : 'Servindo sorrisos desde 2015'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2">
            <h2 className="font-playfair text-4xl font-bold mb-6">{t('about.title')}</h2>
            <p className="text-garfield-brown mb-4">{t('about.description1')}</p>
            <p className="text-garfield-brown mb-6">{t('about.description2')}</p>
            
            <h3 className="font-bold text-xl mb-4">{t('about.special')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {features.map(feature => (
                <div key={feature.id} className="flex flex-col items-center text-center">
                  <div className="bg-garfield-yellow p-3 rounded-full mb-3">
                    <i className={`${feature.icon} text-white`}></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{feature.title}</h3>
                    <p className="text-garfield-light-brown">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
