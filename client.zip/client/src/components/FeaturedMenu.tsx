import { useState, useEffect } from 'react';
import { MenuItem } from '@shared/schema';
import { useLanguage } from '@/lib/i18n/LanguageContext';

// Translation map for menu items
const menuTranslations = {
  // Names
  'Classic Beef Lasagna': 'Lasanha de Carne Clássica',
  'Margherita Pizza': 'Pizza Margherita',
  'Fettuccine Alfredo': 'Fettuccine Alfredo',
  'Garfield\'s Special Lasagna': 'Lasanha Especial do Garfield',
  'Spaghetti Carbonara': 'Espaguete à Carbonara',
  'Chicken Parmesan': 'Frango à Parmegiana',
  
  // Descriptions
  'Layers of pasta, rich meat sauce, and three cheeses, baked to perfection.': 
    'Camadas de massa, molho de carne rico e três queijos, assados até a perfeição.',
  'Classic thin crust pizza with fresh tomatoes, mozzarella, and basil.': 
    'Pizza clássica de massa fina com tomates frescos, muçarela e manjericão.',
  'Creamy pasta with garlic parmesan sauce, perfect for pasta lovers.': 
    'Massa cremosa com molho de parmesão e alho, perfeita para amantes de massa.',
  'Our signature lasagna with extra cheese, meat, and a special secret sauce.': 
    'Nossa lasanha especial com queijo extra, carne e um molho secreto especial.',
  'Traditional pasta with crispy bacon, eggs, and parmesan cheese.': 
    'Massa tradicional com bacon crocante, ovos e queijo parmesão.',
  'Breaded chicken topped with marinara sauce and melted mozzarella.': 
    'Frango empanado coberto com molho marinara e muçarela derretida.'
};

export default function FeaturedMenu() {
  const { t, language } = useLanguage();
  const [featuredDishes, setFeaturedDishes] = useState<MenuItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchFeaturedMenuItems() {
      try {
        setIsLoading(true);
        const response = await fetch('/api/menu-items/featured');
        
        if (!response.ok) {
          throw new Error('Failed to fetch menu items');
        }
        
        const data = await response.json();
        setFeaturedDishes(data);
      } catch (err) {
        console.error('Error fetching featured menu items:', err);
        setError(language === 'en' 
          ? 'Failed to load menu items. Please try again later.'
          : 'Falha ao carregar itens do menu. Por favor, tente novamente mais tarde.');
      } finally {
        setIsLoading(false);
      }
    }

    fetchFeaturedMenuItems();
  }, [language]);

  // Function to translate menu items
  const translateText = (text: string): string => {
    if (language === 'en') return text;
    return menuTranslations[text as keyof typeof menuTranslations] || text;
  };

  return (
    <section id="menu" className="py-16 px-4 bg-garfield-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="font-playfair text-4xl font-bold mb-4">{t('menu.title')}</h2>
          <p className="max-w-2xl mx-auto text-garfield-light-brown">{t('menu.subtitle')}</p>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-garfield-orange"></div>
            <p className="mt-2 text-garfield-light-brown">{t('menu.loading')}</p>
          </div>
        ) : error ? (
          <div className="text-center py-8 text-red-500">
            <p>{error}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredDishes.map(dish => (
              <div key={dish.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="h-56 relative overflow-hidden">
                  <div 
                    className="w-full h-full bg-cover bg-center transition-transform duration-500 hover:scale-110" 
                    style={{ 
                      backgroundImage: dish.imageUrl 
                        ? `url(${dish.imageUrl})` 
                        : 'none'
                    }} 
                  />
                  {dish.featured && (
                    <div className="absolute top-4 right-4 bg-garfield-orange text-white text-sm font-bold px-3 py-1 rounded-full">
                      {language === 'en' ? 'Bestseller' : 'Mais Vendido'}
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="font-playfair text-xl font-bold mb-2">{translateText(dish.name)}</h3>
                  <p className="text-garfield-light-brown mb-4">{translateText(dish.description)}</p>
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-garfield-orange text-xl">R${dish.price.toFixed(2)}</span>
                    <button className="bg-garfield-brown text-white px-4 py-2 rounded-lg hover:bg-garfield-light-brown transition duration-300">
                      {language === 'en' ? 'Order Now' : 'Pedir Agora'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="text-center mt-12">
          <a href="#menu" className="inline-block bg-garfield-orange text-white px-6 py-3 rounded-lg font-medium hover:bg-garfield-yellow transition duration-300">
            {t('menu.cta')}
          </a>
        </div>
      </div>
    </section>
  );
}
