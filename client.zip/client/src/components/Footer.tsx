import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function Footer() {
  const { t, language } = useLanguage();
  
  const getQuickLinks = () => {
    if (language === 'en') {
      return [
        { id: 1, name: "Home", href: "#home" },
        { id: 2, name: "Our Menu", href: "#menu" },
        { id: 3, name: "About Us", href: "#about" },
        { id: 4, name: "Reservations", href: "#reservation" },
        { id: 5, name: "Contact", href: "#contact" }
      ];
    } else {
      return [
        { id: 1, name: "Início", href: "#home" },
        { id: 2, name: "Cardápio", href: "#menu" },
        { id: 3, name: "Sobre Nós", href: "#about" },
        { id: 4, name: "Reservas", href: "#reservation" },
        { id: 5, name: "Contato", href: "#contact" }
      ];
    }
  };

  const getMenuLinks = () => {
    if (language === 'en') {
      return [
        { id: 1, name: "Lasagna Specialties", href: "#" },
        { id: 2, name: "Pasta Dishes", href: "#" },
        { id: 3, name: "Pizza Collection", href: "#" },
        { id: 4, name: "Desserts", href: "#" },
        { id: 5, name: "Kids Menu", href: "#" }
      ];
    } else {
      return [
        { id: 1, name: "Especialidades de Lasanha", href: "#" },
        { id: 2, name: "Pratos de Massa", href: "#" },
        { id: 3, name: "Coleção de Pizzas", href: "#" },
        { id: 4, name: "Sobremesas", href: "#" },
        { id: 5, name: "Menu Infantil", href: "#" }
      ];
    }
  };

  const socialLinks = [
    { id: 1, name: "Facebook", icon: "fab fa-facebook-f", href: "#" },
    { id: 2, name: "Instagram", icon: "fab fa-instagram", href: "#" },
    { id: 3, name: "Twitter", icon: "fab fa-twitter", href: "#" },
    { id: 4, name: "Yelp", icon: "fab fa-yelp", href: "#" }
  ];

  const handleNewsletterSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = new FormData(form).get('email');
    alert(language === 'en' 
      ? `Thank you for subscribing with ${email}!` 
      : `Obrigado por se inscrever com ${email}!`);
    form.reset();
  };

  const quickLinks = getQuickLinks();
  const menuLinks = getMenuLinks();

  return (
    <footer className="bg-garfield-brown text-white pt-16 pb-8">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-4">
              <div className="h-14 w-14 rounded-full bg-[#FF7518] flex items-center justify-center text-white mr-3 border-2 border-garfield-orange">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-8 w-8">
                  <path d="M17 10V5c0-1.1-.9-2-2-2H9c-1.1 0-2 .9-2 2v5a6 6 0 0 0 6 6h0a6 6 0 0 0 6-5.8z" />
                  <path d="M12 13a3 3 0 0 1-3-3V7h6v3a3 3 0 0 1-3 3Z" />
                  <path d="M11 16c-1 1-1 2.6 0 4" />
                  <path d="M13 16c1 1 1 2.6 0 4" />
                  <path d="M7 2v2" />
                  <path d="M17 2v2" />
                </svg>
              </div>
              <h3 className="font-comic text-2xl font-bold text-garfield-orange">Garfield <span className="text-white">Restaurant</span></h3>
            </div>
            <p className="mb-6">
              {language === 'en' 
                ? "Bringing you comfort food that feels like a warm hug, just like our favorite orange cat would want."
                : "Oferecendo comida reconfortante que se sente como um abraço caloroso, como nosso gato laranja favorito gostaria."}
            </p>
            <div className="flex space-x-4">
              {socialLinks.map(link => (
                <a 
                  key={link.id}
                  href={link.href} 
                  aria-label={link.name}
                  className="bg-white bg-opacity-20 hover:bg-garfield-orange w-10 h-10 rounded-full flex items-center justify-center transition duration-300"
                >
                  <i className={link.icon}></i>
                </a>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? "Quick Links" : "Links Rápidos"}
            </h3>
            <ul className="space-y-3">
              {quickLinks.map(link => (
                <li key={link.id}>
                  <a href={link.href} className="hover:text-garfield-orange transition duration-300">{link.name}</a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? "Our Menu" : "Nosso Cardápio"}
            </h3>
            <ul className="space-y-3">
              {menuLinks.map(link => (
                <li key={link.id}>
                  <a href={link.href} className="hover:text-garfield-orange transition duration-300">{link.name}</a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">
              {language === 'en' ? "Newsletter" : "Boletim Informativo"}
            </h3>
            <p className="mb-4">
              {language === 'en'
                ? "Subscribe to our newsletter to get updates on special offers and events."
                : "Inscreva-se em nosso boletim para receber atualizações sobre ofertas especiais e eventos."}
            </p>
            <form className="flex" onSubmit={handleNewsletterSubmit}>
              <input 
                type="email" 
                name="email"
                placeholder={language === 'en' ? "Your email address" : "Seu endereço de email"} 
                className="px-4 py-2 rounded-l-lg flex-grow focus:outline-none text-garfield-brown"
                required
              />
              <button type="submit" className="bg-garfield-orange text-white px-4 py-2 rounded-r-lg hover:bg-garfield-yellow transition duration-300">
                <i className="fas fa-paper-plane"></i>
              </button>
            </form>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white border-opacity-20 text-center">
          <p>&copy; {new Date().getFullYear()} Garfield Restaurant. {t('footer.rights')}</p>
          <p className="text-sm mt-2 text-gray-400">{t('footer.credit')}</p>
        </div>
      </div>
    </footer>
  );
}
