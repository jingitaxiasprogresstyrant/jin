import { useLanguage } from '@/lib/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { IoLanguage } from 'react-icons/io5';

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'pt-BR' : 'en');
  };

  return (
    <Button 
      variant="ghost" 
      size="sm" 
      onClick={toggleLanguage}
      className="flex items-center gap-1 text-garfield-brown hover:text-garfield-orange"
    >
      <IoLanguage className="w-5 h-5" />
      <span className="hidden md:inline">{language === 'en' ? 'PT-BR' : 'EN'}</span>
    </Button>
  );
}