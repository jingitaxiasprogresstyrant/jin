import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function ReservationBanner() {
  const { t, language } = useLanguage();
  
  return (
    <section id="reservation" className="py-16 px-4 bg-garfield-orange relative">
      <div className="container mx-auto max-w-6xl relative z-10">
        <div className="text-center">
          <h2 className="font-playfair text-white text-4xl font-bold mb-6">{t('reservation.title')}</h2>
          <p className="text-white max-w-2xl mx-auto mb-8">{t('reservation.description')}</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="tel:+5511912345678" className="bg-white text-garfield-orange px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition duration-300 flex items-center justify-center">
              <i className="fas fa-phone-alt mr-2"></i> {language === 'en' ? 'Call for Reservation' : 'Ligar para Reserva'}
            </a>
            <a href="#contact" className="bg-garfield-brown text-white px-6 py-3 rounded-lg font-medium hover:bg-garfield-light-brown transition duration-300 flex items-center justify-center">
              <i className="fas fa-calendar-alt mr-2"></i> {t('reservation.cta')}
            </a>
          </div>
        </div>
      </div>
      <div className="absolute inset-0 opacity-10">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="white" className="w-full h-full">
          <rect width="4" height="4" rx="1" />
          <rect x="8" width="4" height="4" rx="1" />
          <rect x="16" width="4" height="4" rx="1" />
          <rect y="8" width="4" height="4" rx="1" />
          <rect x="8" y="8" width="4" height="4" rx="1" />
          <rect x="16" y="8" width="4" height="4" rx="1" />
          <rect y="16" width="4" height="4" rx="1" />
          <rect x="8" y="16" width="4" height="4" rx="1" />
          <rect x="16" y="16" width="4" height="4" rx="1" />
        </svg>
      </div>
    </section>
  );
}
