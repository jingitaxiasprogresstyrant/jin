import { useLanguage } from '@/lib/i18n/LanguageContext';

export default function SpecialOffer() {
  const { t } = useLanguage();

  return (
    <section className="py-12 px-4 bg-garfield-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="flex flex-col md:flex-row">
            <div className="md:w-1/2 bg-garfield-orange p-8 md:p-12 flex items-center">
              <div>
                <h3 className="font-comic text-white text-2xl md:text-3xl font-bold mb-2">{t('special.title')}</h3>
                <h2 className="font-playfair text-white text-3xl md:text-5xl font-bold mb-4">{t('special.subtitle')}</h2>
                <p className="text-white text-lg mb-6">{t('special.description')}</p>
                <a href="#menu" className="inline-block bg-white text-garfield-orange px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition duration-300">{t('special.cta')}</a>
              </div>
            </div>
            <div className="md:w-1/2 relative min-h-[300px]">
              <div className="w-full h-full object-cover bg-[url('https://images.unsplash.com/photo-1574894709920-11b28e7367e3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')] bg-center" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
